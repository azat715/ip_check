# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ip_check']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy-Utils>=0.36.8,<0.37.0',
 'SQLAlchemy>=1.3.22,<2.0.0',
 'fire>=0.3.1,<0.4.0',
 'requests>=2.25.1,<3.0.0']

entry_points = \
{'console_scripts': ['ip_check = ip_check.main:cli']}

setup_kwargs = {
    'name': 'ip-check',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'azat715',
    'author_email': 'azat715@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
